<template>
  <nuxt />
</template>

<script>
export default {}
</script>
